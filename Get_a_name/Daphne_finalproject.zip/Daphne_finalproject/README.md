README
====

To run the app, please install Ruby on Rails 4.2 on Mac OS X, Ubuntu, or Windows. 

see 
http://guides.rubyonrails.org/i18n.html
http://railsapps.github.io/installing-rails.html
for more info and instruction. 
